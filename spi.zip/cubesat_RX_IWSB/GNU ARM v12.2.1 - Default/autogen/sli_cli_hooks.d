autogen/sli_cli_hooks.o: ../autogen/sli_cli_hooks.c \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/toolchain/inc/sl_gcc_preinclude.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/cli/inc/sl_cli.h \
 /home/lmh/SimplicityStudio/v5_workspace/cubesat_RX_IWSB/autogen/sl_component_catalog.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/cli/inc/sl_cli_types.h \
 /home/lmh/SimplicityStudio/v5_workspace/cubesat_RX_IWSB/config/sl_cli_config.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_status.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_slist.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_enum.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/cli/inc/sl_cli_command.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/cli/inc/sl_cli_arguments.h
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/toolchain/inc/sl_gcc_preinclude.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/cli/inc/sl_cli.h:
/home/lmh/SimplicityStudio/v5_workspace/cubesat_RX_IWSB/autogen/sl_component_catalog.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/cli/inc/sl_cli_types.h:
/home/lmh/SimplicityStudio/v5_workspace/cubesat_RX_IWSB/config/sl_cli_config.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_status.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_slist.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_enum.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/cli/inc/sl_cli_command.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/cli/inc/sl_cli_arguments.h:
