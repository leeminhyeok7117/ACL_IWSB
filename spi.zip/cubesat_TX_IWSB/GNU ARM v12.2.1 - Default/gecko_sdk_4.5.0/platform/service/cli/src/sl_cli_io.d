gecko_sdk_4.5.0/platform/service/cli/src/sl_cli_io.o: \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk/platform/service/cli/src/sl_cli_io.c \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/toolchain/inc/sl_gcc_preinclude.h \
 /home/lmh/SimplicityStudio/v5_workspace/cubesat_TX_IWSB/config/sl_cli_config.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk/platform/service/cli/src/sli_cli_io.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream.h \
 /home/lmh/SimplicityStudio/v5_workspace/cubesat_TX_IWSB/autogen/sl_component_catalog.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_enum.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_status.h
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/toolchain/inc/sl_gcc_preinclude.h:
/home/lmh/SimplicityStudio/v5_workspace/cubesat_TX_IWSB/config/sl_cli_config.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk/platform/service/cli/src/sli_cli_io.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream.h:
/home/lmh/SimplicityStudio/v5_workspace/cubesat_TX_IWSB/autogen/sl_component_catalog.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_enum.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_status.h:
