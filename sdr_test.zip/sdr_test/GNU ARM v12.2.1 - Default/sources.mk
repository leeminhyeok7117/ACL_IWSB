################################################################################
# Automatically-generated file. Do not edit!
################################################################################

S79_SRCS := 
OBJ_SRCS := 
S_SRCS := 
ASM_SRCS := 
C_SRCS := 
S79_UPPER_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
EXECUTABLES := 
OBJS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
. \
autogen \
gecko_sdk_4.5.0/app/common/util/app_log \
gecko_sdk_4.5.0/hardware/board/src \
gecko_sdk_4.5.0/hardware/driver/configuration_over_swo/src \
gecko_sdk_4.5.0/hardware/driver/mx25_flash_shutdown/src/sl_mx25_flash_shutdown_usart \
gecko_sdk_4.5.0/platform/Device/SiliconLabs/EFR32FG12P/Source \
gecko_sdk_4.5.0/platform/bootloader/api \
gecko_sdk_4.5.0/platform/bootloader/app_properties \
gecko_sdk_4.5.0/platform/common/src \
gecko_sdk_4.5.0/platform/common/toolchain/src \
gecko_sdk_4.5.0/platform/driver/button/src \
gecko_sdk_4.5.0/platform/driver/debug/src \
gecko_sdk_4.5.0/platform/emdrv/dmadrv/src \
gecko_sdk_4.5.0/platform/emdrv/gpiointerrupt/src \
gecko_sdk_4.5.0/platform/emlib/src \
gecko_sdk_4.5.0/platform/radio/rail_lib/plugin/pa-conversions \
gecko_sdk_4.5.0/platform/radio/rail_lib/plugin/rail_util_protocol \
gecko_sdk_4.5.0/platform/radio/rail_lib/plugin/rail_util_pti \
gecko_sdk_4.5.0/platform/radio/rail_lib/plugin/rail_util_rssi \
gecko_sdk_4.5.0/platform/service/device_init/src \
gecko_sdk_4.5.0/platform/service/iostream/src \
gecko_sdk_4.5.0/platform/service/mpu/src \
gecko_sdk_4.5.0/platform/service/system/src \
gecko_sdk_4.5.0/platform/service/udelay/src \

