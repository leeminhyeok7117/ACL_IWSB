autogen/sl_event_handler.o: ../autogen/sl_event_handler.c \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/toolchain/inc/sl_gcc_preinclude.h \
 ../autogen/sl_event_handler.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_chip.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/em_device.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p433f1024gl125.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/CMSIS/Core/Include/core_cm4.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/CMSIS/Core/Include/cmsis_version.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/CMSIS/Core/Include/cmsis_compiler.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/CMSIS/Core/Include/cmsis_gcc.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/CMSIS/Core/Include/mpu_armv7.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/system_efr32fg12p.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_msc.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_emu.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_rmu.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_cmu.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_crypto.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_gpio_p.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_gpio.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_prs_ch.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_prs.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_ldma_ch.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_ldma.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_fpueh.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_gpcrc.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_timer_cc.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_timer.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_usart.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_leuart.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_letimer.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_cryotimer.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_pcnt.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_i2c.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_adc.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_acmp.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_idac.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_vdac_opa.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_vdac.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_csen.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_lesense_st.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_lesense_buf.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_lesense_ch.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_lesense.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_rtcc_cc.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_rtcc_ret.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_rtcc.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_wdog_pch.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_wdog.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_etm.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_smu.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_trng.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_dma_descriptor.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_devinfo.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_romtable.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_prs_signals.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_dmareq.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_af_ports.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_af_pins.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_common.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_assert.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_system.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_system_generic.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_bus.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_assert.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_core.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_core_generic.h \
 /home/lmh/SimplicityStudio/v5_workspace/sdr_test/autogen/sl_component_catalog.h \
 /home/lmh/SimplicityStudio/v5_workspace/sdr_test/config/emlib_core_debug_config.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_nvic.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_status.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//hardware/board/inc/sl_board_init.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_dcdc.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_lfxo.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_hfxo.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_clocks.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_emu.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/pa-conversions/pa_conversions_efr32.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/common/rail_types.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/chip/efr32/efr32xg1x/rail_chip_specific.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/common/rail_features.h \
 /home/lmh/SimplicityStudio/v5_workspace/sdr_test/config/sl_rail_util_pa_config.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/pa-conversions/pa_curves_efr32.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/pa-conversions/efr32xg1x/sl_rail_util_pa_curves.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/pa-conversions/pa_curve_types_efr32.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/rail_util_pti/sl_rail_util_pti.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/rail_util_rssi/sl_rail_util_rssi.h \
 ../autogen/sl_rail_util_init.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/common/rail.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/common/rail_types.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/common/rail_assert_error_codes.h \
 /home/lmh/SimplicityStudio/v5_workspace/sdr_test/config/sl_rail_util_init_inst0_config.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/btl_interface.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/btl_errorcode.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/btl_reset_info.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/application_properties.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/btl_interface_parser.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/btl_interface_storage.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//hardware/board/inc/sl_board_control.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_enum.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//app/common/util/app_log/app_log.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream.h \
 /home/lmh/SimplicityStudio/v5_workspace/sdr_test/autogen/sl_iostream_handles.h \
 /home/lmh/SimplicityStudio/v5_workspace/sdr_test/autogen/sl_iostream_init_usart_instances.h \
 /home/lmh/SimplicityStudio/v5_workspace/sdr_test/autogen/sl_component_catalog.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream_uart.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emdrv/dmadrv/inc/dmadrv.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emdrv/common/inc/ecode.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_ldma.h \
 /home/lmh/SimplicityStudio/v5_workspace/sdr_test/config/dmadrv_config.h \
 /home/lmh/SimplicityStudio/v5_workspace/sdr_test/config/app_log_config.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/driver/debug/inc/sl_debug_swo.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emdrv/gpiointerrupt/inc/gpiointerrupt.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_gpio.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream_stdlib_config.h \
 ../autogen/sl_iostream_init_usart_instances.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/mpu/inc/sl_mpu.h \
 ../autogen/sl_simple_button_instances.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/driver/button/inc/sl_simple_button.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/driver/button/inc/sl_button.h \
 ../autogen/sl_iostream_init_instances.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//hardware/driver/configuration_over_swo/inc/sl_cos.h
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/toolchain/inc/sl_gcc_preinclude.h:
../autogen/sl_event_handler.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_chip.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/em_device.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p433f1024gl125.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/CMSIS/Core/Include/core_cm4.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/CMSIS/Core/Include/cmsis_version.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/CMSIS/Core/Include/cmsis_compiler.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/CMSIS/Core/Include/cmsis_gcc.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/CMSIS/Core/Include/mpu_armv7.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/system_efr32fg12p.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_msc.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_emu.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_rmu.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_cmu.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_crypto.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_gpio_p.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_gpio.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_prs_ch.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_prs.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_ldma_ch.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_ldma.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_fpueh.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_gpcrc.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_timer_cc.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_timer.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_usart.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_leuart.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_letimer.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_cryotimer.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_pcnt.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_i2c.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_adc.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_acmp.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_idac.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_vdac_opa.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_vdac.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_csen.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_lesense_st.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_lesense_buf.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_lesense_ch.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_lesense.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_rtcc_cc.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_rtcc_ret.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_rtcc.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_wdog_pch.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_wdog.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_etm.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_smu.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_trng.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_dma_descriptor.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_devinfo.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_romtable.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_prs_signals.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_dmareq.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_af_ports.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/Device/SiliconLabs/EFR32FG12P/Include/efr32fg12p_af_pins.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_common.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_assert.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_system.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_system_generic.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_bus.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_assert.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_core.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_core_generic.h:
/home/lmh/SimplicityStudio/v5_workspace/sdr_test/autogen/sl_component_catalog.h:
/home/lmh/SimplicityStudio/v5_workspace/sdr_test/config/emlib_core_debug_config.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_nvic.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_status.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//hardware/board/inc/sl_board_init.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_dcdc.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_lfxo.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_hfxo.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_clocks.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/device_init/inc/sl_device_init_emu.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/pa-conversions/pa_conversions_efr32.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/common/rail_types.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/chip/efr32/efr32xg1x/rail_chip_specific.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/common/rail_features.h:
/home/lmh/SimplicityStudio/v5_workspace/sdr_test/config/sl_rail_util_pa_config.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/pa-conversions/pa_curves_efr32.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/pa-conversions/efr32xg1x/sl_rail_util_pa_curves.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/pa-conversions/pa_curve_types_efr32.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/rail_util_pti/sl_rail_util_pti.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/plugin/rail_util_rssi/sl_rail_util_rssi.h:
../autogen/sl_rail_util_init.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/common/rail.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/common/rail_types.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/radio/rail_lib/common/rail_assert_error_codes.h:
/home/lmh/SimplicityStudio/v5_workspace/sdr_test/config/sl_rail_util_init_inst0_config.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/btl_interface.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/btl_errorcode.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/btl_reset_info.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/application_properties.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/btl_interface_parser.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/bootloader/api/btl_interface_storage.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//hardware/board/inc/sl_board_control.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_enum.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//app/common/util/app_log/app_log.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream.h:
/home/lmh/SimplicityStudio/v5_workspace/sdr_test/autogen/sl_iostream_handles.h:
/home/lmh/SimplicityStudio/v5_workspace/sdr_test/autogen/sl_iostream_init_usart_instances.h:
/home/lmh/SimplicityStudio/v5_workspace/sdr_test/autogen/sl_component_catalog.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream_uart.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emdrv/dmadrv/inc/dmadrv.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emdrv/common/inc/ecode.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_ldma.h:
/home/lmh/SimplicityStudio/v5_workspace/sdr_test/config/dmadrv_config.h:
/home/lmh/SimplicityStudio/v5_workspace/sdr_test/config/app_log_config.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/driver/debug/inc/sl_debug_swo.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emdrv/gpiointerrupt/inc/gpiointerrupt.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/emlib/inc/em_gpio.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream_stdlib_config.h:
../autogen/sl_iostream_init_usart_instances.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/mpu/inc/sl_mpu.h:
../autogen/sl_simple_button_instances.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/driver/button/inc/sl_simple_button.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/driver/button/inc/sl_button.h:
../autogen/sl_iostream_init_instances.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//hardware/driver/configuration_over_swo/inc/sl_cos.h:
