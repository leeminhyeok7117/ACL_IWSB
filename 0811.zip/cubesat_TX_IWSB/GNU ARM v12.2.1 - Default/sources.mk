################################################################################
# Automatically-generated file. Do not edit!
################################################################################

S79_SRCS := 
OBJ_SRCS := 
S_SRCS := 
ASM_SRCS := 
C_SRCS := 
S79_UPPER_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
EXECUTABLES := 
OBJS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
. \
autogen \
gecko_sdk_4.5.0/app/common/util/app_log \
gecko_sdk_4.5.0/hardware/board/src \
gecko_sdk_4.5.0/hardware/driver/configuration_over_swo/src \
gecko_sdk_4.5.0/hardware/driver/mx25_flash_shutdown/src/sl_mx25_flash_shutdown_usart \
gecko_sdk_4.5.0/platform/Device/SiliconLabs/EFR32FG12P/Source \
gecko_sdk_4.5.0/platform/bootloader/api \
gecko_sdk_4.5.0/platform/bootloader/app_properties \
gecko_sdk_4.5.0/platform/common/src \
gecko_sdk_4.5.0/platform/common/toolchain/src \
gecko_sdk_4.5.0/platform/driver/button/src \
gecko_sdk_4.5.0/platform/driver/debug/src \
gecko_sdk_4.5.0/platform/driver/leddrv/src \
gecko_sdk_4.5.0/platform/emdrv/dmadrv/src \
gecko_sdk_4.5.0/platform/emdrv/gpiointerrupt/src \
gecko_sdk_4.5.0/platform/emdrv/nvm3/src \
gecko_sdk_4.5.0/platform/emlib/src \
gecko_sdk_4.5.0/platform/radio/rail_lib/plugin/pa-conversions \
gecko_sdk_4.5.0/platform/radio/rail_lib/plugin/rail_util_power_manager_init \
gecko_sdk_4.5.0/platform/radio/rail_lib/plugin/rail_util_pti \
gecko_sdk_4.5.0/platform/security/sl_component/sl_mbedtls_support/src \
gecko_sdk_4.5.0/platform/security/sl_component/sl_psa_driver/src \
gecko_sdk_4.5.0/platform/service/cli/src \
gecko_sdk_4.5.0/platform/service/device_init/src \
gecko_sdk_4.5.0/platform/service/iostream/src \
gecko_sdk_4.5.0/platform/service/mpu/src \
gecko_sdk_4.5.0/platform/service/power_manager/src \
gecko_sdk_4.5.0/platform/service/sleeptimer/src \
gecko_sdk_4.5.0/platform/service/system/src \
gecko_sdk_4.5.0/platform/service/token_manager/src \
gecko_sdk_4.5.0/platform/service/udelay/src \
gecko_sdk_4.5.0/protocol/flex/app-framework-common \
gecko_sdk_4.5.0/protocol/flex/ota-unicast-bootloader/ota-unicast-bootloader-server \
gecko_sdk_4.5.0/protocol/flex/poll \
gecko_sdk_4.5.0/protocol/flex/stack/config \
gecko_sdk_4.5.0/protocol/flex/stack/core \
gecko_sdk_4.5.0/protocol/flex/stack/framework \
gecko_sdk_4.5.0/util/silicon_labs/silabs_core/memory_manager \
gecko_sdk_4.5.0/util/third_party/mbedtls/library \
gecko_sdk_4.5.0/util/third_party/printf \
gecko_sdk_4.5.0/util/third_party/printf/src \

