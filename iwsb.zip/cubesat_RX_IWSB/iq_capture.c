/***************************************************************************//**
 * @file    iq_capture.c
 * @brief   IWSB — RAIL IQ 캡처 코어 구현 (Connect 스택과 시분할 공유)
 *
 *  자세한 설계 배경은 iq_capture.h 주석 참조.
 *  이 파일은 Connect/OTA 코드를 전혀 건드리지 않으며, 오직 측정 슬롯에서만
 *  RAIL 을 잠시 IQ 모드로 빌렸다가 패킷 모드로 원복한다.
 *******************************************************************************
 * SPDX-License-Identifier: Zlib
 ******************************************************************************/
#include "iq_capture.h"
#include "rail.h"
#include "rail_types.h"
#include "sl_sleeptimer.h"

// -----------------------------------------------------------------------------
//  RAIL 핸들 가로채기 — RAILCb_SetupRxFifo override (librail weak 기본 대체)
//
//  RAIL 은 부팅 시 이 콜백을 호출하여 앱이 RX FIFO 를 설정하도록 한다.
//  Connect(SoC)는 librail 의 weak 기본 구현을 쓰지만, 여기서 strong 으로
//  재정의하면:
//    1) 스택이 넘겨준 railHandle 을 붙잡아 두고(IQ 재설정에 사용),
//    2) 우리 정적 버퍼로 RX FIFO 를 설정(패킷 수신에도 그대로 사용됨).
//  ※ 링크 시 이 strong 정의가 librail 의 weak 정의를 대체한다(중복 아님).
// -----------------------------------------------------------------------------
static RAIL_Handle_t s_rail = NULL;
static uint8_t       s_rxfifo[IQ_RXFIFO_SIZE] __attribute__((aligned(4)));

RAIL_Status_t RAILCb_SetupRxFifo(RAIL_Handle_t railHandle)
{
  s_rail = railHandle;
  uint16_t sz = IQ_RXFIFO_SIZE;
  RAIL_Status_t st = RAIL_SetRxFifo(railHandle, s_rxfifo, &sz);
  // 멀티프로토콜 등으로 아직 설정 불가한 경우는 성공으로 처리(스택 기본 동작 유지).
  if (st == RAIL_STATUS_INVALID_STATE) {
    return RAIL_STATUS_NO_ERROR;
  }
  return st;
}

bool iq_capture_ready(void) { return s_rail != NULL; }

// -----------------------------------------------------------------------------
//  데이터 컨피그: 패킷 모드(Connect 평시) / IQ FIFO 모드(캡처 순간)
// -----------------------------------------------------------------------------
static const RAIL_DataConfig_t k_cfg_packet = {
  .txSource = TX_PACKET_DATA,
  .rxSource = RX_PACKET_DATA,
  .txMethod = PACKET_MODE,
  .rxMethod = PACKET_MODE,
};

static const RAIL_DataConfig_t k_cfg_iq = {
  .txSource = TX_PACKET_DATA,
  .rxSource = RX_IQDATA_FILTLSB,   // 하위 16bit I/Q → iq_sample_t 와 매칭
  .txMethod = FIFO_MODE,
  .rxMethod = FIFO_MODE,
};

// 라디오를 유휴로 두고 패킷 모드로 원복(캡처 종료/실패 공통 경로).
static void restore_packet_mode(void)
{
  RAIL_Idle(s_rail, RAIL_IDLE_ABORT, true);
  RAIL_ConfigData(s_rail, &k_cfg_packet);
  RAIL_ResetFifo(s_rail, false, true);
  // 실제 RX 재개는 호출측이 emberSetRadioChannel(home) 으로 트리거한다
  // (스택이 자신의 채널/파라미터로 RAIL_StartRx 를 다시 건다).
}

uint16_t iq_capture_burst(uint8_t channel, iq_sample_t *out,
                          uint16_t max_samples, uint16_t decim,
                          uint32_t timeout_ms)
{
  if (s_rail == NULL || out == NULL || max_samples == 0U) {
    return 0U;
  }
  if (decim == 0U) decim = 1U;

  // 1) 라디오 유휴 → IQ FIFO 모드로 전환.
  RAIL_Idle(s_rail, RAIL_IDLE_ABORT, true);
  if (RAIL_ConfigData(s_rail, &k_cfg_iq) != RAIL_STATUS_NO_ERROR) {
    restore_packet_mode();
    return 0U;
  }
  RAIL_ResetFifo(s_rail, false, true);   // RX FIFO 비우고 캡처 시작 준비

  // 2) 캡처 채널에서 수신 시작(스택 우회 — 이 순간엔 우리가 라디오 소유).
  if (RAIL_StartRx(s_rail, channel, NULL) != RAIL_STATUS_NO_ERROR) {
    restore_packet_mode();
    return 0U;
  }

  // 3) FIFO 에서 IQ 바이트를 폴링으로 읽어 디시메이션하며 저장.
  //    한 복소 샘플 = 4바이트(I16 LE, Q16 LE).
  uint16_t n         = 0U;
  uint32_t decim_ctr = 0U;
  uint8_t  raw[4];
  const uint32_t t0            = sl_sleeptimer_get_tick_count();
  const uint32_t timeout_ticks = sl_sleeptimer_ms_to_tick(timeout_ms);

  while (n < max_samples) {
    if ((sl_sleeptimer_get_tick_count() - t0) > timeout_ticks) {
      break;   // 무신호/저속 PHY → 상한에서 탈출
    }
    uint16_t avail = RAIL_GetRxFifoBytesAvailable(s_rail);
    while (avail >= 4U && n < max_samples) {
      if (RAIL_ReadRxFifo(s_rail, raw, 4U) != 4U) {
        break;
      }
      avail -= 4U;
      if ((decim_ctr++ % decim) == 0U) {
        out[n].i = (int16_t)((uint16_t)raw[0] | ((uint16_t)raw[1] << 8));
        out[n].q = (int16_t)((uint16_t)raw[2] | ((uint16_t)raw[3] << 8));
        n++;
      }
    }
  }

  // 4) 패킷 모드로 원복(Connect/OTA 정상 동작 재개).
  restore_packet_mode();
  return n;
}
