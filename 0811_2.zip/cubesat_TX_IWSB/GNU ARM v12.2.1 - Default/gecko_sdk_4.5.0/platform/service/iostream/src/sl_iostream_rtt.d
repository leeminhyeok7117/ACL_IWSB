gecko_sdk_4.5.0/platform/service/iostream/src/sl_iostream_rtt.o: \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk/platform/service/iostream/src/sl_iostream_rtt.c \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/toolchain/inc/sl_gcc_preinclude.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream_rtt.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream.h \
 /home/lmh/SimplicityStudio/v5_workspace/cubesat_TX_IWSB/autogen/sl_component_catalog.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_enum.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_status.h \
 /home/lmh/SimplicityStudio/SDKs/gecko_sdk//util/third_party/segger/systemview/SEGGER/SEGGER_RTT.h \
 /home/lmh/SimplicityStudio/v5_workspace/cubesat_TX_IWSB/config/SEGGER_RTT_Conf.h
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/toolchain/inc/sl_gcc_preinclude.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream_rtt.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/service/iostream/inc/sl_iostream.h:
/home/lmh/SimplicityStudio/v5_workspace/cubesat_TX_IWSB/autogen/sl_component_catalog.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_enum.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//platform/common/inc/sl_status.h:
/home/lmh/SimplicityStudio/SDKs/gecko_sdk//util/third_party/segger/systemview/SEGGER/SEGGER_RTT.h:
/home/lmh/SimplicityStudio/v5_workspace/cubesat_TX_IWSB/config/SEGGER_RTT_Conf.h:
